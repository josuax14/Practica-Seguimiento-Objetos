function [salida salida2] = RecalcularCentroides(DatColorAgrupa,TABcentroides,NumeroEsferas)

nocambia = 0; % si 0 false si 1 true

[F C] = size (DatColorAgrupa);
[FF CC] =size(TABcentroides);
DatColorAgrupa = double (DatColorAgrupa);
TABcentroides = double (TABcentroides);
auxiliar = [];
media = [];

while(nocambia == 0)
    nocambia = 1;    
    centr = -1;
    for i = 1 : F
        aux = 9999999;
        for j = 1 : FF
            
          if(sqrt((((TABcentroides(j,2) - DatColorAgrupa(i,2))^ 2) + ((TABcentroides(j,3) - DatColorAgrupa(i,3))^ 2) + ((TABcentroides(j,4) - DatColorAgrupa(i,4))^ 2))) < aux)
              aux = sqrt((((TABcentroides(j,2) - DatColorAgrupa(i,2))^ 2) + ((TABcentroides(j,3) - DatColorAgrupa(i,3))^ 2) + ((TABcentroides(j,4) - DatColorAgrupa(i,4))^ 2)));
              centr = j;
          end
        end
        if(DatColorAgrupa(i,1) ~= centr)
            DatColorAgrupa(i,1) = centr;
            nocambia = 0;
            nocambia
        end
    end
    
    if(nocambia == 0)
       
        for p = 1 : NumeroEsferas            
            auxiliar = DatColorAgrupa(find(DatColorAgrupa(:,1) == p),:);
            media = cat(1, media,mean(auxiliar));
        end
    end
    
end
DatColorAgrupa = uint8 (DatColorAgrupa);
TABcentroides = uint8 (TABcentroides);

salida = media;
salida2=DatColorAgrupa;
end