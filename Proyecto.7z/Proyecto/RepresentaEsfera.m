function RepresentaEsfera(Punto,Radio)

[R,G,B] = sphere(100);
% Matrices de puntos de una esfera centrada en el origen de radio unidad
x = Radio*R(:)+ Punto(1);
y = Radio*G(:)+ Punto(2);
z = Radio*B(:)+ Punto(3);
plot3(x,y,z, '.b')

end