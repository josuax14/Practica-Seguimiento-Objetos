function salida = CalcularCentroide(Matriz)

salida = mean(Matriz(:,2:4))
end