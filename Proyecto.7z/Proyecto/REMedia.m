function salida = REMedia(DatosFondo,DatosColor,Centroide)
maxi = REtodocolor(DatosColor,Centroide);
mini = REtodocolorsinRuido(DatosFondo,DatosColor,Centroide);

res = ((maxi + mini) / 2);
RepresentaEsfera(Centroide,res);
salida = res;
end