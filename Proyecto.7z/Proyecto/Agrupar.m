function salida = Agrupar(DatosColor,NumeroEsferas)


desv = std(double(DatosColor));
desv = desv(2:4);
pos = (find(desv == max(desv)));

DatosDis = DatosColor(:,pos + 1);
dist = (max(DatosDis) - min(DatosDis)); 

intervalo = (dist/NumeroEsferas)+1;

mini = min(DatosDis);
filas= numel(DatosDis);

for i = 1 : NumeroEsferas
    maxi= mini + intervalo;
    for j= 1 : filas
        if(DatosDis(j,1) >= mini && DatosDis(j,1) < maxi)
            DatosColor(j,1)=i;
        end
    end
    mini= maxi;
end


salida = DatosColor;

end


