function salida = REtodocolor(DatosColor,Centroide)
%RGB

aux = 0;
[N M] = size(DatosColor);
DatosColor= double (DatosColor);
for i = 1: N
    aux2 = sqrt((((Centroide(1) - DatosColor(i,2))^ 2) + ((Centroide(2) - DatosColor(i,3))^ 2) + ((Centroide(3) - DatosColor(i,4))^ 2)));
    if(aux < aux2)
        aux=aux2;
        
    end
end

RepresentaEsfera(Centroide,aux);
salida = aux;
end