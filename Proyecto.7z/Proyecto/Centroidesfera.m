function salida = Centroidesfera(DatColorAgrupa,NC)
CentroidesG = []
for i = 1 : NC
    
aux = DatColorAgrupa(find(DatColorAgrupa(:,1) == i),:)
G = mean(aux);
CentroidesG = cat(1,CentroidesG,G);
end


salida = CentroidesG

end