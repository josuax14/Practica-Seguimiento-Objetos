%% Incicializacion de Datos Color y Datos Fondo
NumeroEsferas = 8;
I1 = imread('Imagen5.png','png')
imtool(I1)

Aux = roipoly(I1) %% Matriz Logica de los lugares marcados
R = I1(:,:,1)
G = I1(:,:,2)
B = I1(:,:,3)

Rf = R(Aux)
Gf = G(Aux)
Bf = B(Aux)
Unos = ones(size(Rf),1)
Unos = Unos * 1 % Numero de la imagen a la que pertenece

DatosColor2 = cat(2,Unos,Rf,Gf,Bf)
DatosColor = cat(1,DatosColor,DatosColor2)

DatosFondo = zeros(1,4)
I1 = imread('Imagen1.png','png')

Aux = roipoly(I1) %% Matriz Logica de los lugares marcados
R = I1(:,:,1)
G = I1(:,:,2)
B = I1(:,:,3)

Rf = R(Aux)
Gf = G(Aux)
Bf = B(Aux)

Unos = ones(size(Rf),1)
Unos = Unos * 1 % Numero de la imagen a la que pertenece

DatosFondo2 = cat(2,Unos,Rf,Gf,Bf)
DatosFondo = cat(1,DatosFondo,DatosFondo2)

% Fin Apartado 2 IMPORTANTE

%% Pintar Datos Color y Datos Fondo

hold on
plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r')
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g')

hold off

% Fin Apartado 3.1 IMPORTANTE

%% Calculo del Centroide //FUNCION

Centroide = CalcularCentroide(DatosColor)


%% Representa Esfera //FUNCION

hold on

plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');
RepresentaEsfera(Centroide,100);

hold off


%% Representa Esfera que coja todo el Color //FUNCION

hold on

plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');
DistMax = REtodocolor(DatosColor,Centroide); 

hold off


%% Representa Esfera sin Ruido //FUNCION

hold on

plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');
DistMin = REtodocolorsinRuido(DatosFondo,Centroide); 

hold off



%% Representa Esfera Media //FUNCION

hold on

plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');
DistMedia = REMedia(DatosFondo,DatosColor,Centroide);

hold off


%% Funcion saber si pertenece determinados puntos a la esfera //Funcion

I = imread('Imagen5.png','png');
ImagenFiltrada = FiltrarPuntosImagen(I,Centroide,DistMin) % Por parametro la imagen 3D color, el centroide y el radio de la esfera del centroide.
imtool(ImagenFiltrada)

%% Funcion Agrupar y tabcentroides //Funcion

DatColorAgrupa = Agrupar(DatosColor,NumeroEsferas); % Funcion de agrupacion de puntos
TABcentroides = Centroidesfera(DatColorAgrupa,NumeroEsferas); % Funcion que calcula los centroides de las esferas generadas en Agrupar

hold on

DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 1),:),TABcentroides(1,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 2),:),TABcentroides(2,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 3),:),TABcentroides(3,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 4),:),TABcentroides(4,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 5),:),TABcentroides(5,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 6),:),TABcentroides(6,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 7),:),TABcentroides(7,2:4));
DistMin = REtodocolor(DatColorAgrupa(find(DatColorAgrupa(:,1) == 8),:),TABcentroides(8,2:4));

grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 1),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* y');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 2),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* r');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 3),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* y');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 4),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* r');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 5),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* y');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 6),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* r');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 7),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* y');
grupito = DatColorAgrupa(find(DatColorAgrupa(:,1) == 8),:)
plot3(grupito(:,2),grupito(:,3),grupito(:,4),'* r');


plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');
plot3(TABcentroides(1,2),TABcentroides(1,3),TABcentroides(1,4),'* b');
%DistMin = REtodocolorsinRuido(DatosFondo,DatColorAgrupa(find(DatColorAgrupa(:,1) == 1),:),TABcentroides(1,2:4));
%DistMin = REtodocolorsinRuido(DatosFondo,DatColorAgrupa(find(DatColorAgrupa(:,1) == 2),:),TABcentroides(2,2:4)); 
%DistMin = REtodocolorsinRuido(DatosFondo,DatColorAgrupa(find(DatColorAgrupa(:,1) == 3),:),TABcentroides(3,2:4));
%DistMin = REtodocolorsinRuido(DatosFondo,DatColorAgrupa(find(DatColorAgrupa(:,1) == 4),:),TABcentroides(4,2:4));


%% Reajustes de Centroides //Funcion

[TABfinal DatosCentroidesFinal] = RecalcularCentroides(DatColorAgrupa,TABcentroides,NumeroEsferas) % Reajuste de los centroides de las esferas

hold on
plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');

REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==1),:),TABfinal(1,2:4));
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==2),:),TABfinal(2,2:4));
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==3),:),TABfinal(3,2:4));
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==4),:),TABfinal(4,2:4)); 
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==5),:),TABfinal(5,2:4))
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==6),:),TABfinal(6,2:4));
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==7),:),TABfinal(7,2:4));
REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==8),:),TABfinal(8,2:4));
hold off

hold on
plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');

REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==1),:),TABfinal(1,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==2),:),TABfinal(2,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==3),:),TABfinal(3,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==4),:),TABfinal(4,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==5),:),TABfinal(5,2:4))
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==6),:),TABfinal(6,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==7),:),TABfinal(7,2:4));
REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==8),:),TABfinal(8,2:4));
hold off

hold on
plot3(DatosColor(:,2),DatosColor(:,3),DatosColor(:,4),'* r');
plot3(DatosFondo(:,2),DatosFondo(:,3),DatosFondo(:,4),'* g');

REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==1),:),TABfinal(1,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==2),:),TABfinal(2,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==3),:),TABfinal(3,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==4),:),TABfinal(4,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==5),:),TABfinal(5,2:4))
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==6),:),TABfinal(6,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==7),:),TABfinal(7,2:4));
REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==8),:),TABfinal(8,2:4));
hold off


%% A�adir a la tabla de centroides Distancias de confianza //Funcion
TABfinall = IncluirDistanciasTAB(TABfinal,DatosCentroidesFinal,DatosFondo,NumeroEsferas);


%% Binarizar Imagen con Etiquetado //Funcion
info = mmfileinfo('Ejemplo.avi'); % Informacion del Archivo de Video
NumFilasFrame = info.Video.Height;
NumeroColumnasFrame = info.Video.Width;
Duracion = info.Duration;
FramesData = aviread('Ejemplo.avi'); % lectura de los frames del archivo AVI
NumeroFrames = length(FramesData);
FPS = round(NumeroFrames/Duracion);
%Numero_de_Frame = 10;
%I = FramesData(1,Numero_de_Frame).cdata; % Lectura D�cimo Frame
%%%% Generacion de un nuevo video a partir del archivo de video leido
aviobj = avifile('EjemploProc4.avi', 'COMPRESSION', 'NONE');
aviobj.Fps = FPS; % El video tendra la misma tasa de frames
%%%%%%%%%%%%% Imagen mas alejada para hallar el valor min de filtrado de
%%% areas
I = imread('Imagen9.png', 'png');
seleccion = 7; % 5max 6med 7min
MatBin = BinarizarTAB(I,TABfinall,seleccion);
ME= bwlabel(MatBin, 8);
maximo= max(max(ME));
Area= [];
for i=1 : maximo
    [N M]= size(find(ME==i));
    Area= [Area, N];
end

Area=floor((max(Area))/2);

for i=1:NumeroFrames
    I = FramesData(1,i).cdata;
    seleccion = 7; % 5max 6med 7min
    MatBin = BinarizarTAB(I,TABfinall,seleccion); % 0max 1med 2min
    L = bwlabel(MatBin, 8);
    MF=bwareaopen(L, Area); % Etiquetada cuenta el area de cada etiqueta y filtra por le numero menor q el numero introducido 
    MF2 = bwlabel(MF, 8); % volver a etiquetar la matriz
    puntos=regionprops(MF2, 'Centroid'); % calcula centroides de las etiquetas
    aux=[];
    aux= cat (1,puntos.Centroid); % estructura especial
    R= double(I(:,:,1));
    G= double(I(:,:,2));
    B= double(I(:,:,3));
    for i=1 : max(max(MF2)) %% bucle desde 1 hasta la etiqueta maxima
        Y = floor(aux(i,1)); %% Y e X se almacenan al contrario
        X = floor(aux(i,2));
        R(X-2:X+2,Y-2:Y+2) = 255;
        G(X-2:X+2,Y-2:Y+2) = 0;
        B(X-2:X+2,Y-2:Y+2) = 0;
    end

    %imshow(I)

    %R(MF==1)= 255;
    %G(MF==1)= 0;
    %B(MF==1)= 255;


    R= uint8(R);
    G= uint8(G);
    B= uint8(B);


    Ic= cat(3,R,G,B);
    %imtool(Ic);




aviobj = addframe(aviobj,Ic);
end
aviobj = close(aviobj);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


