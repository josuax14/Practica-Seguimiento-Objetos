function salida = BinarizarTAB(I,TABfinall,tipo)
I = double(I);
[F C] = size(I);
C = C/3;
Binaria = zeros(F,C);

for i = 1 : F

    for j = 1 : C
        for k = 1 : 8
       
        if(sqrt((((TABfinall(k,2) - I(i,j,1))^ 2) + ((TABfinall(k,3) - I(i,j,2))^ 2) + ((TABfinall(k,4) - I(i,j,3))^ 2))) < TABfinall(k,tipo))
        Binaria(i,j) = 1;
        end
        
        end
        
    end

end

salida = Binaria;
end
