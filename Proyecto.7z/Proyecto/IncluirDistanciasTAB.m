function salida = IncluirDistanciasTAB(TABfinal,DatosCentroidesFinal,DatosFondo,NumeroEsferas)

aux = [];
aux2 = [];

for i = 1 : NumeroEsferas;
        
        dist = REtodocolor(DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==i),:),TABfinal(i,2:4));
        aux = cat(1,aux,dist);
        
end

aux2 = cat(2,aux2,aux);
aux = [];
for i = 1 : NumeroEsferas;
        
        dist = REMedia(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==i),:),TABfinal(i,2:4));
        aux = cat(1,aux,dist);
        
end
aux2 = cat(2,aux2,aux);
aux = [];
for i = 1 : NumeroEsferas;
        
        dist = REtodocolorsinRuido(DatosFondo,DatosCentroidesFinal(find(DatosCentroidesFinal(:,1)==i),:),TABfinal(i,2:4));
        aux = cat(1,aux,dist);
        
end

aux2 = cat(2,aux2,aux);
salida = cat(2,TABfinal,aux2);

end