function salida = REtodocolorsinRuido(DatosFondo,Color,Centroide)
%RGB

aux = 256;
pos = 0;
[N M] = size(DatosFondo);
DatosFondo = double (DatosFondo);
for i = 1: N
    aux2 = sqrt((((Centroide(1) - DatosFondo(i,2))^ 2) + ((Centroide(2) - DatosFondo(i,3))^ 2) + ((Centroide(3) - DatosFondo(i,4))^ 2)));
    if(aux > aux2)
        aux=aux2;
        pos=i;
    end
end
if(REtodocolor(Color,Centroide) < aux) 
aux = REtodocolor(Color,Centroide)
end
RepresentaEsfera(Centroide,aux)
salida = aux;
end